package view;

import controller.EventController;
import controller.InputSource;
import view.componentsGui.CalendarUI;
import view.utilsGui.CommandGenerator;

import java.util.Scanner;

/**
 * The EventView class that handles the user interface for the event management system.
 * Implements the View component in the MVC architecture.
 */
public class EventView {

  /** The event controller responsible for handling commands and managing events. */
  private EventController eventController;

  /**
   * Constructor that initializes a new EventController.
   */
  public EventView() {
    this.eventController = new EventController();
  }

  /**
   * Runs the application in interactive mode, accepting user commands continuously
   * until the user enters "exit".
   */
  public void runInteractiveMode() {
    Scanner scanner = new Scanner(System.in);
    while (true) {
      System.out.print("Enter Command: ");
      String command = scanner.nextLine();
      if (command.equals("exit")) {
        System.out.println("Goodbye!");
        break;
      }
      try {
        eventController.filterCommand(command);
      } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
        break;
      }
    }
    scanner.close();
  }

  /**
   * Runs the application in headless mode, processing commands from a specified file.
   *
   * @param filename the path to the file containing commands to process
   */
  public void runHeadlessMode(String filename) {
    eventController.headlessMode(new InputSource(filename));
  }

  /**
   * Runs the application in GUI mode, displaying a graphical calendar interface.
   * This method initializes the UI components, sets up event listeners, and
   * starts the graphical user interface.
   */
  public void runGUIMode() {
    CommandGenerator commandGenerator = new CommandGenerator();
    CalendarUI ui = new CalendarUI(eventController, commandGenerator);
    eventController.getEventHandler().addUIListener(ui);
    ui.start();
  }

  /**
   * Prints usage instructions for the application to the console.
   * This includes the available command-line options and examples.
   */
  private static void printUsage() {
    System.out.println("Usage:");
    System.out.println("  java -jar Program.jar");
    System.out.println("  java -jar Program.jar --mode interactive");
    System.out.println("  java -jar Program.jar --mode headless <filename>");
  }

  /**
   * Main method for running the application. Processes command-line arguments to determine the
   * operating mode.
   *
   * @param args command-line arguments in the format: --mode [interactive|headless filename]
   */
  public static void main(String[] args) {
    EventView eventView = new EventView();

    if (args.length == 0) {
      // No args → Launch GUI by default
      eventView.runGUIMode();
    } else if (args.length >= 2 && args[0].equalsIgnoreCase("--mode")) {
      if (args[1].equalsIgnoreCase("interactive")) {
        eventView.runInteractiveMode();
      } else if (args[1].equalsIgnoreCase("headless") && args.length == 3) {
        eventView.runHeadlessMode(args[2]);
      } else {
        printUsage();
      }
    } else {
      printUsage();
    }
  }
}